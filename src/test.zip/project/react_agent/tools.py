from typing import Any, Callable, List, Optional, cast
from project.react_agent.configuration import Configuration
import json, os, time
import pandas as pd
import requests


# async def search(query: str) -> Optional[dict[str, Any]]:
#     """Search for general web results.

#     This function performs a search using the Tavily search engine, which is designed
#     to provide comprehensive, accurate, and trusted results. It's particularly useful
#     for answering questions about current events.
#     """
#     configuration = Configuration.from_context()
#     wrapped = TavilySearch(max_results=configuration.max_search_results)
#     return cast(dict[str, Any], await wrapped.ainvoke({"query": query}))

def get_user_intent(content: str) -> dict:
    """
    模型生成意图后必须使用此工具，通过调用外部API确认用户意图
    """

    try:
        # 发送POST请求
        response = requests.post(url = "http://localhost:8081/intent", json={"content": content}, headers={"Content-Type": "application/json"})
        # 检查响应状态
        response.raise_for_status()
        # 解析响应数据
        result = response.json()
        return result
        
    except requests.exceptions.RequestException as e:
        print(f"请求发生错误: {str(e)}")
        return {"error": str(e)}
    except json.JSONDecodeError as e:
        print(f"解析响应数据失败: {str(e)}")
        return {"error": "解析响应数据失败"}
    

def summary_csv(file_path: str):
    """Read the csv file and return summary data
    
    This function should be applied before considering what elements should be incorporated into the EDA analysis or hypothesis testing"""

    df = pd.read_csv(os.path.join('data', file_path))
    return df.describe().to_dict()


def generate_notebook(query: str):
    """create the json format of notebook for the given query"""
    requirements = [
        "Use os.path.join('../data', file_path) for file reading. ",
        "Use Chinese descriptions. ",
        "Ensure Chinese characters display correctly in plots if any. ",
        "Ensure the code is executable.",
        "If hypothesis testing is required, the default significance level is 0.05, and conclusions should be described based on this value"
    ]
    description = f"根据要求{requirements},完成{query}的代码，并封装为ipynb框架的json格式，不要做任何发散，直接返回可运行的框架json。"

    return description

def save_notebook(notebook):
    """Save the json format of notebook to ipynb file."""
    
    def get_notebook_name():
        return 'notebook_' + str(int(time.time())) + '.ipynb'
    
    file_name = get_notebook_name()
    with open(os.path.join('dest', file_name), 'w', encoding='utf-8') as f:
        json.dump(notebook, f, ensure_ascii=False, indent=1)
    return f"{file_name} 保存成功"


TOOLS: List[Callable[..., Any]] = [generate_notebook, save_notebook]
PRETOOLS: List[Callable[..., Any]] = [summary_csv, get_user_intent]
