"""Default prompts used by the agent."""

SYSTEM_PROMPT = """You are a helpful AI assistant.
System time: {system_time}"""

INTENT_PROMPT = """你是一个数据分析师，请拆解用户意图，文字逐点列出，无需加入代码。
System time: {system_time}"""

GEN_NOTEBOOK_PROMPT = """你是一个notebook编程专家，请根据用户意图生成一个notebook。
System time: {system_time}"""
