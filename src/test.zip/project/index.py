# !/usr/bin/python
# -*- coding: utf-8 -*-
# @time    : 2025/05/27 11:42
# @author  : Leah
# @function: post service of fastapi

from datetime import UTC, datetime
from typing import Dict, List, Literal, cast, Optional

from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph import StateGraph
from langgraph.prebuilt import ToolNode

from project.react_agent.configuration import Configuration
from project.react_agent.state import InputState, State
from project.react_agent.tools import TOOLS
from project.react_agent.utils import load_chat_model
from project.react_agent.router import route_model_output

import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sys
import os

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Define the function that calls the model

def call_model(state: State) -> Dict[str, List[AIMessage]]:
    """Call the LLM powering our "agent".

    This function prepares the prompt, initializes the model, and processes the response.

    Args:
        state (State): The current state of the conversation.
        config (RunnableConfig): Configuration for the model run.

    Returns:
        dict: A dictionary containing the model's response message.
    """
    configuration = Configuration.from_context()

    # Initialize the model with tool binding. Change the model or add more tools here.
    model = load_chat_model(configuration.model)# .bind_tools(TOOLS)

    # Format the system prompt. Customize this to change the agent's behavior.
    system_message = configuration.system_prompt.format(
        system_time=datetime.now(tz=UTC).isoformat()
    )

    # Get the model's response
    response = cast(
        AIMessage,
        model.invoke(
            [{"role": "system", "content": system_message}, *state.messages]
        ),
    )

    # Handle the case when it's the last step and the model still wants to use a tool
    if state.is_last_step and response.tool_calls:
        return {
            "messages": [
                AIMessage(
                    id=response.id,
                    content="Sorry, I could not find an answer to your question in the specified number of steps.",
                )
            ]
        }

    # Return the model's response as a list to be added to existing messages
    return {"messages": [response]}

app = FastAPI()

# Define a new graph
builder = StateGraph(State, input=InputState, config_schema=Configuration)
builder.add_node(call_model)
builder.add_edge("__start__", "call_model")
builder.add_edge("call_model", "__end__")

# builder.add_node("tools", ToolNode(TOOLS))
# builder.add_edge("__start__", "call_model")
# builder.add_conditional_edges("call_model",route_model_output,)
# builder.add_edge("tools", "call_model")

# Compile the builder into an executable graph
graph = builder.compile(name="ReAct Agent")
class RequestModel(BaseModel):
    content: str
    threadid: str

# class ResponseModel(BaseModel):
#     content: str
#     role: str = "assistant"
#     tool_calls: List[Dict]
#     id: str
#     type: Literal["ai", "function"]

# @app.post('/app', response_model=ResponseModel)
def invoke(_input):
    print(_input, flush=True)
    sys.path.append('/home/mw/project')

    try:
        logger.info(f"Received request with content: {_input['content']}")
        config = {"configurable": {"thread_id": _input['threadid']}}
        result = graph.invoke({"messages": [HumanMessage(content=_input['content'])]}, config)
    
        logger.info("Successfully processed request")
        return {
            "content": result["messages"][-1].content,
            "role": "assistant",
            "tool_calls": result["messages"][-1].tool_calls,
            "id": result["messages"][-1].id,
            "type": result["messages"][-1].type
        }

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Error processing request: {str(e)}"
        )
